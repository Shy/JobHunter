# JobHunter

## Description
Solution to help people find jobs.

## Installation
    npm install

## Usage
    node JobHunter.js person.json

## Person.json
Included is an example person: `example_person.json`. JSON file should include a current_employer, role a user is seeking, a desired stack, location desired, minimum salery, job_type and a maximum age for job postings in months. 
